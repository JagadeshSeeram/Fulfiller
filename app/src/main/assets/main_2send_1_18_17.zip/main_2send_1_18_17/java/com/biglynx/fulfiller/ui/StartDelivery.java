package com.biglynx.fulfiller.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.biglynx.fulfiller.MainActivity;
import com.biglynx.fulfiller.R;
import com.biglynx.fulfiller.adapter.MessagesAdapter;
import com.biglynx.fulfiller.adapter.StartDeliveryAdapter;
import com.biglynx.fulfiller.app.MyApplication;
import com.biglynx.fulfiller.models.InterestDTO;
import com.biglynx.fulfiller.models.MessagesModel;
import com.biglynx.fulfiller.network.FullFillerApiWrapper;
import com.biglynx.fulfiller.network.NetworkOperationListener;
import com.biglynx.fulfiller.network.NetworkResponse;
import com.biglynx.fulfiller.utils.AppPreferences;
import com.biglynx.fulfiller.utils.AppUtil;
import com.biglynx.fulfiller.utils.CaptureSignatureView;
import com.biglynx.fulfiller.utils.Common;
import com.google.gson.Gson;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.biglynx.fulfiller.utils.Constants.OOPS_SOMETHING_WENT_WRONG;


public class StartDelivery extends AppCompatActivity implements View.OnClickListener,
        SwipeRefreshLayout.OnRefreshListener {

    private static final int READ_PHONE_STATE_PERMISSION = 1;
    private static int statusId = 0;
    ImageView icon_back, subway_arrow_imv, trackimage_imv, ontheway_imv, pickedup_imv, delivered_imv, companylogo_imv;
    TextView deliverydate_tv, confirmtoken_tv, readytopick_tv, mindistance_tv, maxdistance_tv, notifiy_btn_tv, notifieddata_tv,
            ontheway_tv, pickedup_tv, delivered_tv, confirm_deli_tv, confirm_pickup_btn_tv, day_tv, time_tv, phoneno_tv, name_tv, address_tv;
    LinearLayout subway_details_LI, details_LI, deliv_customers_LI, googlemaps_LI, confirmorders_LI;
    ProgressBar progress_bar;
    private Handler handler = new Handler();
    private float startpos;
    private int progressStatus;
    private static int deviceswidth;
    private EditText confirm_code_ev, no_ofpackages_ev, no_ofcustomers_ev;
    private ListView orderlist_LI;
    private InterestDTO interest, responseInterestObj;
    private StartDeliveryAdapter startDeliveryAdapter;
    private SimpleDateFormat simpleDateFormat;
    private TextView fulfillmentid_tv;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private MessagesAdapter adapter;
    private FullFillerApiWrapper apiWrapper;
    private boolean newMsgSent = true;
    private EditText replyText_ev;
    private TextView reply_tv, retailerName_tv;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ScrollView mScrollView;
    private SwitchCompat confirmSwitch;
    private View signatureLayout;
    private View signatureSave;
    private View signatureCancel;
    private String orderId;
    private String mCurrentPhotoPath;
    private static String responseString;
    private CaptureSignatureView signView;
    private static String blobId;

    protected void onCreate(Bundle savedInstanceState) {
        // To make activity full screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_delivery);

        initViews();
        progressStatus = 0;

        if (Common.isNetworkAvailable(this)) {

            Common.showDialog(this);
            getpermissions();
            Log.d("resolution", "" + getScreenResolution(this));


        } else
            AppUtil.toast(StartDelivery.this, getString(R.string.check_interent_connection));
    }

    private void getpermissions() {
        int sdkVersion = Build.VERSION.SDK_INT;

        if (sdkVersion >= 23) {
            // Getting permissins to Read from External Storage
            getPermissionsToReadPhoneState();
        } else
            callServices(true);
    }

    public void getPermissionsToReadPhoneState() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // The permission is NOT already granted.
            // Check if the user has been asked about this permission already and
            // denied
            // it. If so, we want to give more explanation about why the
            // permission is needed.
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_PHONE_STATE)) {
                // Show our own UI to explain to the user why we need to read the
                // external storage
                // before requesting the permission and showing the default UI

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(R.string.permisn_denied));
                builder.setMessage(getString(R.string.explantn_for_requstng_permissn));
                builder.setPositiveButton("RE-TRY", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //User has asked the permission again.
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    ActivityCompat.requestPermissions(StartDelivery.this, new
                                                    String[]{android.Manifest.permission.READ_PHONE_STATE},
                                            READ_PHONE_STATE_PERMISSION);
                                }
                            }
                        });
                builder.setNegativeButton("IM SURE", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //User has denied the permission.
                                dialog.dismiss();
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.setCancelable(false);
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
                return;
            } else {
                // Fire off an async request to actually get the permission
                // This will show the standard permission request dialog UI
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    ActivityCompat.requestPermissions(StartDelivery.this, new
                                    String[]{android.Manifest.permission.READ_PHONE_STATE},
                            READ_PHONE_STATE_PERMISSION);
                    return;
                }
            }
        } else {
            //Permission already granted
            callServices(true);
        }

    }

    // Callback with the request from calling requestPermissions(...)
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        // Make sure it's our original READ_CONTACTS request
        if (requestCode == READ_PHONE_STATE_PERMISSION) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Granted", Toast.LENGTH_SHORT).show();
                callServices(true);
            } else {
                Toast.makeText(this, "Denied", Toast.LENGTH_SHORT).show();
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_PHONE_STATE)) {
                    AlertDialog dialog = new AlertDialog.Builder(StartDelivery.this)
                            .setMessage(getString(R.string.accept_permission_in_settings))
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .create();
                    dialog.setCancelable(false);
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();
                }
            }
        } else {
            // super.onRequestPermissionsResult(requestCode, permissions,
            // grantResults);
        }
    }

    //StartDelivery API
    private void callServices(final boolean updateUI) {
        HashMap<String, Object> hashMap = new HashMap<>();
        if (getIntent().hasExtra("fulfillerid")) {
            hashMap.put("fulfillerid", getIntent().getExtras().get("fulfillerid"));
            hashMap.put("confirmationcode", getIntent().getExtras().get("confirmationcode"));
            hashMap.put("name", getIntent().getExtras().get("name"));
            hashMap.put("latitude", getIntent().getExtras().get("latitude"));
            hashMap.put("longitude", getIntent().getExtras().get("longitude"));
        } else {
            hashMap.put("fulfillerid", AppUtil.ifNotEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FulfillerId")) ?
                    AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FulfillerId") : "");
            hashMap.put("confirmationcode", AppUtil.ifNotEmpty(interest.Fulfillments.FulfillerInterests.ConfirmationCode) ?
                    interest.Fulfillments.FulfillerInterests.ConfirmationCode : "");
            hashMap.put("name", AppUtil.ifNotEmpty(interest.Fulfillments.LocationContactPerson) ?
                    interest.Fulfillments.LocationContactPerson : "");
            hashMap.put("latitude", AppUtil.ifNotEmpty(String.valueOf(interest.Fulfillments.PickUpMapLatitude)) ?
                    interest.Fulfillments.PickUpMapLatitude : "");
            hashMap.put("longitude", AppUtil.ifNotEmpty(String.valueOf(interest.Fulfillments.PickUpMapLongitude)) ?
                    interest.Fulfillments.PickUpMapLongitude : "");
        }
        hashMap.put("deviceid", getDeviceId());
        apiWrapper.startDeliveryCall(AppPreferences.getInstance(StartDelivery.this).getSignInResult() != null ?
                        AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("AuthNToken") : "",
                hashMap, new Callback<InterestDTO>() {
                    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void onResponse(Call<InterestDTO> call, Response<InterestDTO> response) {
                        Common.disMissDialog();
                        if (response.isSuccessful()) {
                            responseInterestObj = response.body();
                            if (updateUI) {
                                buildUI(responseInterestObj);
                                updateProgress(responseInterestObj.Fulfillments.DeliveryStatusId);
                            }
                        } else {
                            try {
                                AppUtil.parseErrorMessage(StartDelivery.this, response.errorBody().string());
                            } catch (IOException e) {
                                AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                                e.printStackTrace();
                            }
                            if (interest == null) {
                                startActivity(new Intent(StartDelivery.this, LoginActivity.class));
                                return;
                            }
                            AppUtil.CheckErrorCode(StartDelivery.this, response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<InterestDTO> call, Throwable t) {
                        Common.disMissDialog();
                        AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                        if (interest == null) {
                            startActivity(new Intent(StartDelivery.this, LoginActivity.class));
                            return;
                        }
                    }
                });

        if (newMsgSent) {
            callGetMessagesAPI(true);
        }
    }

    public void callUpdateDeliverySignLayout(String orderId) {
        signatureLayout.setVisibility(View.VISIBLE);
        this.orderId = orderId;
    }

    public void callUpdateDeliveryStatusAPi(final int deliveryStatusId, String orderId, String blobId) {
        Log.d(StartDelivery.class.getSimpleName(), "Statsu ID :: " + deliveryStatusId);
        HashMap<String, Object> hashMap = getDeliveryStatusDetails();
        hashMap.put("DeliveryStatusId", deliveryStatusId);
        if (deliveryStatusId == 4 || deliveryStatusId == 5) {
            hashMap.put("OrderId", orderId);
            if (blobId != null) {
                hashMap.put("DelSign", blobId);
            }
        }
        FullFillerApiWrapper apiWrapper = new FullFillerApiWrapper();
        Common.showDialog(StartDelivery.this);
        apiWrapper.updateDeliverYStatusCall(AppPreferences.getInstance(StartDelivery.this).getSignInResult() != null ?
                        AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("AuthNToken") : "",
                hashMap, new Callback<InterestDTO>() {
                    @Override
                    public void onResponse(Call<InterestDTO> call, Response<InterestDTO> response) {
                        if (response.isSuccessful()) {
                            updateProgress(deliveryStatusId);
                            if (deliveryStatusId == 4 || deliveryStatusId == 5)
                                callServices(false);
                            if (deliveryStatusId == 6) {
                                if (interest != null)
                                    finishActivity();
                                else {
                                    startActivity(new Intent(StartDelivery.this, LoginActivity.class));
                                    finish();
                                }
                            }
                        } else {
                            try {
                                AppUtil.parseErrorMessage(StartDelivery.this, response.errorBody().string());
                            } catch (IOException e) {
                                AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                                e.printStackTrace();
                            }
                            AppUtil.CheckErrorCode(StartDelivery.this, response.code());
                        }
                        Common.disMissDialog();
                    }

                    @Override
                    public void onFailure(Call<InterestDTO> call, Throwable t) {
                        Common.disMissDialog();
                        AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                    }
                });
    }

    public void callUpdateDeliveryStatusAPi(final int deliveryStatusId, String orderId) {
        callUpdateDeliveryStatusAPi(deliveryStatusId, orderId, null);
    }

    public HashMap<String, Object> getDeliveryStatusDetails() {
        HashMap<String, Object> hashMap = new HashMap<>();
        if (getIntent().hasExtra("fulfillerid")) {
            hashMap.put("fulfillerid", getIntent().getExtras().get("fulfillerid"));
        } else {
            hashMap.put("fulfillerid", AppUtil.ifNotEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FulfillerId")) ?
                    AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FulfillerId") : "");
        }
        if (responseInterestObj.Fulfillments.DeliveryPartner != null)
            hashMap.put("confirmationcode", responseInterestObj.Fulfillments.DeliveryPartner.ConfirmationCode);
        else
            hashMap.put("confirmationcode", responseInterestObj.Fulfillments.DeliveryPerson.ConfirmationCode);

        if (AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("Role").equals("DeliveryPartner")) {
            if (!TextUtils.isEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("BusinessLegalName")))
                hashMap.put("FriendlyName", AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("BusinessLegalName"));
        } else {
            if (!TextUtils.isEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FirstName")))
                hashMap.put("FriendlyName", AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FirstName"));
        }
        hashMap.put("GeoLocationLatitude", AppUtil.ifNotEmpty(String.valueOf(responseInterestObj.Fulfillments.PickUpMapLatitude)) ?
                responseInterestObj.Fulfillments.PickUpMapLatitude : "");
        hashMap.put("GeoLocationLongitude", AppUtil.ifNotEmpty(String.valueOf(responseInterestObj.Fulfillments.PickUpMapLongitude)) ?
                responseInterestObj.Fulfillments.PickUpMapLongitude : "");
        hashMap.put("UniqueDeviceId", getDeviceId());
        hashMap.put("DeliveryStatusId", "");
        hashMap.put("OrderId", "");
        hashMap.put("DelSign", "");

        return hashMap;
    }

    private Object getDeviceId() {
        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        String deviceID = telephonyManager.getDeviceId();
        Log.d(StartDelivery.class.getSimpleName(), "Device ID :: " + deviceID);
        return deviceID;
    }

    private void initViews() {
        apiWrapper = new FullFillerApiWrapper();
        icon_back = (ImageView) findViewById(R.id.icon_back);
        subway_arrow_imv = (ImageView) findViewById(R.id.subway_arrow_imv);
        trackimage_imv = (ImageView) findViewById(R.id.trackimage_imv);
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        //live status update initilizations
        ontheway_imv = (ImageView) findViewById(R.id.ontheway_imv);
        pickedup_imv = (ImageView) findViewById(R.id.pickedup_imv);
        delivered_imv = (ImageView) findViewById(R.id.delivered_imv);
        companylogo_imv = (ImageView) findViewById(R.id.companylogo_imv);
        ontheway_tv = (TextView) findViewById(R.id.ontheway_tv);
        pickedup_tv = (TextView) findViewById(R.id.pickedup_tv);
        delivered_tv = (TextView) findViewById(R.id.delivered_tv);
        orderlist_LI = (ListView) findViewById(R.id.orderlist_LI);
        //confirm delivery intilizations
        confirm_pickup_btn_tv = (TextView) findViewById(R.id.confirm_pickup_btn_tv);
        no_ofpackages_ev = (EditText) findViewById(R.id.no_ofpackages_ev);
        no_ofcustomers_ev = (EditText) findViewById(R.id.no_ofcustomers_ev);
        day_tv = (TextView) findViewById(R.id.day_tv);
        time_tv = (TextView) findViewById(R.id.time_tv);
        //orders to customer
        confirm_deli_tv = (TextView) findViewById(R.id.confirm_deli_tv);

        phoneno_tv = (TextView) findViewById(R.id.phoneno_tv);
        name_tv = (TextView) findViewById(R.id.name_tv);
        address_tv = (TextView) findViewById(R.id.address_tv);

        confirm_code_ev = (EditText) findViewById(R.id.confirm_code_ev);

        startpos = trackimage_imv.getX();
        subway_details_LI = (LinearLayout) findViewById(R.id.subway_details_LI);
        details_LI = (LinearLayout) findViewById(R.id.details_LI);
        progress_bar = (ProgressBar) findViewById(R.id.progress_bar);

        deliv_customers_LI = (LinearLayout) findViewById(R.id.deliv_customers_LI);
        googlemaps_LI = (LinearLayout) findViewById(R.id.googlemaps_LI);
        confirmorders_LI = (LinearLayout) findViewById(R.id.confirmorders_LI);

        deliverydate_tv = (TextView) findViewById(R.id.deliverydate_tv);
        confirmtoken_tv = (TextView) findViewById(R.id.confirmtoken_tv);
        readytopick_tv = (TextView) findViewById(R.id.readytopick_tv);
        mindistance_tv = (TextView) findViewById(R.id.mindistance_tv);
        maxdistance_tv = (TextView) findViewById(R.id.maxdistance_tv);
        notifiy_btn_tv = (TextView) findViewById(R.id.notifiy_btn_tv);
        notifieddata_tv = (TextView) findViewById(R.id.notifieddata_tv);
        fulfillmentid_tv = (TextView) findViewById(R.id.fulfillmentid_tv);
        replyText_ev = (EditText) findViewById(R.id.replyText_ev);
        reply_tv = (TextView) findViewById(R.id.reply_tv);
        retailerName_tv = (TextView) findViewById(R.id.retailerName_tv);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_To_Refresh_Layout);
        mScrollView = (ScrollView) findViewById(R.id.deliveryScrollView);
        confirmSwitch = (SwitchCompat) findViewById(R.id.confirmSwitch);

        signatureLayout = findViewById(R.id.signature_layout);
        signatureSave = findViewById(R.id.signature_save);
        signatureCancel = findViewById(R.id.signature_cancel);
        signView = (CaptureSignatureView) findViewById(R.id.signature_view);
        signatureCancel.setOnClickListener(this);
        signatureSave.setOnClickListener(this);

        mRecyclerView = (RecyclerView) findViewById(R.id.messages_listView);
        mLayoutManager = new LinearLayoutManager(StartDelivery.this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        adapter = new MessagesAdapter(StartDelivery.this);
        mRecyclerView.setAdapter(adapter);

        icon_back.setVisibility(View.VISIBLE);
        icon_back.setOnClickListener(this);
        subway_arrow_imv.setOnClickListener(this);
        notifiy_btn_tv.setOnClickListener(this);
        confirm_deli_tv.setOnClickListener(this);
        confirm_pickup_btn_tv.setOnClickListener(this);
        reply_tv.setOnClickListener(this);
        swipeRefreshLayout.setOnRefreshListener(this);

        if (getIntent().hasExtra("interest"))
            interest = (InterestDTO) getIntent().getSerializableExtra("interest");
    }

    private static String getScreenResolution(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        deviceswidth = width - 100;
        return "{" + width + "," + height + "}";
    }

    public void updateProgress(int deliveryStatusId) {
        if (deliveryStatusId == 1) {
            progressStatus = 0;
            updateProgressbar(5);
        } else if (deliveryStatusId == 2) {
            updateProgressbar(35);
        } else if (deliveryStatusId == 3 || deliveryStatusId == 4 || deliveryStatusId == 5) {
            updateProgressbar(75);
        } else if (deliveryStatusId == 6)
            updateProgressbar(100);
    }

    private void updateProgressbar(final int max) {

        // Start the lengthy operation in a background thread
        progress_bar.setProgress(progressStatus);

        Log.d("intial progressbar", startpos + "," + progressStatus);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressStatus < max) {
                    // Update the progress status
                    progressStatus += 1;

                    // Try to sleep the thread for 20 milliseconds
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    // Update the progress bar
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            progress_bar.setProgress(progressStatus);
                            trackimage_imv.setX(progressStatus * (deviceswidth / 100));
                            ontheway_imv.setImageResource(R.drawable.ontheway_g);
                            ontheway_tv.setTextColor(Color.parseColor("#94C96F"));

                            if (progressStatus == 5) {
                                if (!googlemaps_LI.isShown())
                                    googlemaps_LI.setVisibility(View.VISIBLE);
                            }
                            if (progressStatus == 35) {
                                googlemaps_LI.setVisibility(View.GONE);
                                confirmorders_LI.setVisibility(View.VISIBLE);
                                pickedup_imv.setImageResource(R.drawable.pickedup_g);
                                pickedup_tv.setTextColor(Color.parseColor("#94C96F"));
                            }

                            if (progressStatus > 50) {
                                if (deliv_customers_LI.getVisibility() == View.VISIBLE) {
                                } else {
                                    googlemaps_LI.setVisibility(View.GONE);
                                    confirmorders_LI.setVisibility(View.GONE);
                                    deliv_customers_LI.setVisibility(View.VISIBLE);
                                    pickedup_imv.setImageResource(R.drawable.pickedup_g);
                                    pickedup_tv.setTextColor(Color.parseColor("#94C96F"));
                                }
                            }
                            if (progressStatus == 100) {
                                delivered_imv.setImageResource(R.drawable.delivered_g);
                                delivered_tv.setTextColor(Color.parseColor("#94C96F"));
                            }
                        }
                    });
                }


            }
        }).start(); // Start the operation
    }

    /**
     * Creating the bitmap and get
     *
     * @param
     */
    private void createImageFile(Bitmap bitmap) throws IOException {
        // Create an image file name
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, bytes);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        FileOutputStream stream = new FileOutputStream(image);
        stream.write(bytes.toByteArray());
        stream.close();
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = "file:" + image.getAbsolutePath();
        mCurrentPhotoPath = image.getAbsolutePath();

        new SendImageResult().execute(mCurrentPhotoPath);
    }

    public class SendImageResult extends AsyncTask<String, String, String> {
        URL url = null;
        String responce = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Common.showDialog(StartDelivery.this);
        }

        @Override
        protected String doInBackground(String... arg0) {
            uploadUserPhoto(arg0[0]);

            return responce;
        }

        @Override
        protected void onPostExecute(String results) {
            super.onPostExecute(results);
            Common.disMissDialog();
            //  finish();
            try {
                JSONArray result = new JSONArray(responseString);
                for (int i = 0; i < result.length(); i++) {
                    JSONObject jsonObject = result.getJSONObject(i);
                    blobId = jsonObject.getString("UniqueId");
                    if (orderId != null) {
                        callUpdateDeliveryStatusAPi(5, orderId, blobId);
                    }
                    break;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    public void uploadUserPhoto(String filepath) {

        try {
            Log.d("file path", "" + filepath);

            File file = new File(filepath);
            HttpPost httppost = new HttpPost("https://www.eyece.com/Services/Api/FileSystem/UploadPublic?extension=png");
            String boundary = "----" + System.currentTimeMillis() + "----";
            // httppost.setHeader("Content-type", "multipart/form-data; boundary=" + boundary);
            org.apache.http.entity.mime.MultipartEntity multipartEntity = new org.apache.http.entity.mime.MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
            // httppost.containsHeader(lineEnd + twoHyphens + boundary + lineEnd);
            // multipartEntity.addPart("filepath", new StringBody(""));
            //  httppost.containsHeader(lineEnd + twoHyphens + boundary + lineEnd);
            multipartEntity.addPart("image", new FileBody(file, "image/jpg"));
            //  httppost.setHeader("Accept", "application/json");
            // httppost.containsHeader(lineEnd);
            httppost.setEntity(multipartEntity);
            //Log.d("entity",""+multipartEntity.getContent());
            HttpParams params = new BasicHttpParams();

            // params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
            //                System.out.println("executing request " + multipartEntity.getContent());
            HttpClient httpClient = new DefaultHttpClient();
            httpClient.execute(httppost, new PhotoUploadResponseHandler());

        } catch (Exception e) {
            Log.e("data", e.getLocalizedMessage(), e);
        }
    }

    private class PhotoUploadResponseHandler implements ResponseHandler<Object> {

        @Override
        public Object handleResponse(HttpResponse response)
                throws ClientProtocolException, IOException {
            //10-08 03:19:13.966: E/res(27552): File Uploaded Successfully...
            // Log.e("jsonObject res", ""+response);
            HttpEntity r_entity = response.getEntity();
            responseString = EntityUtils.toString(r_entity);
            Log.e("jsonObject res", "" + responseString);


            return null;
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.signature_save:
                // First image save and get the blobID and send the blobID to deliveryStatus API
                if (signatureLayout.isShown())
                    signatureLayout.setVisibility(View.GONE);
                if (signView != null) {
                    Bitmap bitmap = signView.getBitmap();
                    if (bitmap != null) {
                        try {
                            createImageFile(bitmap);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;
            case R.id.signature_cancel:
                if (signatureLayout.isShown()) {
                    signatureLayout.setVisibility(View.GONE);
                }
                orderId = null;
                break;
            case R.id.icon_back:
                finish();
                break;

            case R.id.confirm_deli_tv:
                if (confirm_code_ev.getText().toString().equalsIgnoreCase("CONFIRMED")) {
                 /* googlemaps_LI.setVisibility(View.GONE);
                  confirmorders_LI.setVisibility(View.GONE);
                  deliv_customers_LI.setVisibility(View.VISIBLE);*/
                    if (responseInterestObj.Fulfillments.Orders != null && responseInterestObj.Fulfillments.Orders.size() > 0) {
                        int noOfOrders = responseInterestObj.Fulfillments.Orders.size();
                        int deliveredItemsCount = 0;
                        for (int i = 0; i < responseInterestObj.Fulfillments.Orders.size(); i++) {
                            if (responseInterestObj.Fulfillments.Orders.get(i).Status.equalsIgnoreCase("Delivered"))
                                deliveredItemsCount = deliveredItemsCount + 1;
                        }
                        if (noOfOrders == deliveredItemsCount) {
                            callUpdateDeliveryStatusAPi(6, null);
                        } else
                            AppUtil.toast(StartDelivery.this, "All orders are not delivered...");

                    }
                } else {
                    AppUtil.toast(StartDelivery.this, "Please type CONFIRMED");
                }
                break;
            case R.id.confirm_pickup_btn_tv:

                if (AppUtil.ifNotEmpty(no_ofcustomers_ev.getText().toString()) &&
                        AppUtil.ifNotEmpty(no_ofpackages_ev.getText().toString()) &&
                        confirmSwitch.isChecked()
                        ) {
                    //callUpdateDeliveryStatusAPi(3, null);

                    if (no_ofpackages_ev.getText().toString() == responseInterestObj.Fulfillments.TotalPackages &&
                            no_ofcustomers_ev.getText().toString() == responseInterestObj.Fulfillments.OrderCount) {
                        callUpdateDeliveryStatusAPi(3, null);
                    } else
                        AppUtil.toast(StartDelivery.this, getString(R.string.not_matched));
                } else
                    AppUtil.toast(StartDelivery.this, getString(R.string.mandatory));
                break;

            case R.id.notifiy_btn_tv:
                callUpdateDeliveryStatusAPi(2, null);
                break;
            case R.id.subway_arrow_imv:
                if (details_LI.isShown()) {
                    details_LI.setVisibility(View.GONE);
                    subway_arrow_imv.setImageResource(R.drawable.down_white_arrow);
                } else {
                    subway_arrow_imv.setImageResource(R.drawable.up_white_arrow);
                    details_LI.setVisibility(View.VISIBLE);
                    mScrollView.smoothScrollTo((int) details_LI.getX(), (int) details_LI.getY());
                }
                break;
            case R.id.reply_tv:
                if (!TextUtils.isEmpty(replyText_ev.getText().toString())) {
                    callPostMessagesAPI(replyText_ev.getText().toString());
                    replyText_ev.setText("");
                    replyText_ev.setHint(getString(R.string.send_msg_to_retailer));
                } else {
                    AppUtil.toast(StartDelivery.this, getString(R.string.message_cant_be_empty));
                }
                break;
        }
    }

    private void callPostMessagesAPI(String msg) {
        if (!Common.isNetworkAvailable(MyApplication.getInstance())) {
            AppUtil.toast(StartDelivery.this, "Network disconnected. Please check");
            return;
        }

        Common.showDialog(StartDelivery.this);
        final HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("FulfillmentId", responseInterestObj.Fulfillments.FulfillmentId);
        if (getIntent().hasExtra("FulfillerId"))
            hashMap.put("FulfillerId", getIntent().getExtras().get("FulfillerId"));
        else
            hashMap.put("FulfillerId", AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FulfillerId"));

        if (AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("Role").equals("DeliveryPartner")) {
            if (!TextUtils.isEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("BusinessLegalName")))
                hashMap.put("FlulfillerName", AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("BusinessLegalName"));
        } else {
            if (!TextUtils.isEmpty(AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FirstName")))
                hashMap.put("FlulfillerName", AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("FirstName"));
        }
        hashMap.put("RetailerId", "");
        hashMap.put("RetailerName", "");
        hashMap.put("MessageFrom", "Fulfiller");
        hashMap.put("Message", msg.trim());

        apiWrapper.postFulfillerMessagesCall(AppPreferences.getInstance(StartDelivery.this).getSignInResult() != null ?
                        AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("AuthNToken") : "",
                hashMap, new Callback<List<MessagesModel>>() {
                    @Override
                    public void onResponse(Call<List<MessagesModel>> call, Response<List<MessagesModel>> response) {
                        Common.disMissDialog();
                        if (response.isSuccessful()) {
                            newMsgSent = true;
                            MessagesModel messagesModel = new MessagesModel();
                            messagesModel.FlulfillerName = (String) hashMap.get("FlulfillerName");
                            messagesModel.Message = (String) hashMap.get("Message");
                            adapter.getModelArrayList().add(messagesModel);
                            adapter.notifyDataSetChanged();
                        } else {
                            newMsgSent = false;
                            try {
                                AppUtil.parseErrorMessage(StartDelivery.this, response.errorBody().string());
                            } catch (IOException e) {
                                AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                                e.printStackTrace();
                            }

                            AppUtil.CheckErrorCode(StartDelivery.this, response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<MessagesModel>> call, Throwable t) {
                        Common.disMissDialog();
                        newMsgSent = false;
                        AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                    }
                });
    }

    private void callGetMessagesAPI(final boolean showProgress) {
        //Messages API - GET
        if (!Common.isNetworkAvailable(MyApplication.getInstance())) {
            AppUtil.toast(StartDelivery.this, "Network disconnected. Please check");
            return;
        }
        if (showProgress)
            Common.showDialog(StartDelivery.this);

        String fulfillmentId;
        if (interest != null)
            fulfillmentId = interest.Fulfillments.FulfillmentId;
        else if (responseInterestObj != null)
            fulfillmentId = responseInterestObj.Fulfillments.FulfillmentId;
        else
            fulfillmentId = "";

        apiWrapper.getAllMessagesCall(AppPreferences.getInstance(StartDelivery.this).getSignInResult() != null ?
                        AppPreferences.getInstance(StartDelivery.this).getSignInResult().optString("AuthNToken") : "",
                fulfillmentId, new Callback<List<MessagesModel>>() {
                    @Override
                    public void onResponse(Call<List<MessagesModel>> call, Response<List<MessagesModel>> response) {
                        if (response.isSuccessful()) {
                            newMsgSent = false;
                            adapter.setItems(response.body());
                            if (!subway_details_LI.isShown())
                                subway_details_LI.setVisibility(View.VISIBLE);
                        } else {
                            if (interest == null && responseInterestObj == null) {
                                startActivity(new Intent(StartDelivery.this, LoginActivity.class));
                                finish();
                            }
                            newMsgSent = true;
                            if (subway_details_LI.isShown())
                                subway_details_LI.setVisibility(View.GONE);
                            try {
                                AppUtil.parseErrorMessage(StartDelivery.this, response.errorBody().string());
                            } catch (IOException e) {
                                AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                                e.printStackTrace();
                            }
                            AppUtil.CheckErrorCode(StartDelivery.this, response.code());
                        }

                        if (showProgress)
                            Common.disMissDialog();
                        else
                            swipeRefreshLayout.setRefreshing(false);

                    }

                    @Override
                    public void onFailure(Call<List<MessagesModel>> call, Throwable t) {
                        if (showProgress)
                            Common.disMissDialog();
                        else
                            swipeRefreshLayout.setRefreshing(false);
                        newMsgSent = true;
                        if (subway_details_LI.isShown())
                            subway_details_LI.setVisibility(View.GONE);
                        AppUtil.toast(StartDelivery.this, OOPS_SOMETHING_WENT_WRONG);
                        if (interest == null && responseInterestObj == null) {
                            startActivity(new Intent(StartDelivery.this, LoginActivity.class));
                            finish();
                        }
                    }
                });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void buildUI(InterestDTO mInterest) {

        if (AppUtil.ifNotEmpty(mInterest.CompanyLogo)) {
            if (!companylogo_imv.isShown())
                companylogo_imv.setVisibility(View.VISIBLE);
            retailerName_tv.setVisibility(View.GONE);
            Picasso.with(StartDelivery.this).load(mInterest.CompanyLogo)
                    .error(R.drawable.cougar_logo).into(companylogo_imv);
        } else {
            companylogo_imv.setVisibility(View.GONE);
            retailerName_tv.setVisibility(View.VISIBLE);
            retailerName_tv.setText(mInterest.Fulfillments.RetailerLocation.Retailer.BusinessLegalName);
        }

        fulfillmentid_tv.setText(mInterest.Fulfillments.FulfillmentId);

        if (responseInterestObj.Fulfillments.DeliveryPartner != null)
            confirmtoken_tv.setText(responseInterestObj.Fulfillments.DeliveryPartner.ConfirmationCode);
        else
            confirmtoken_tv.setText(responseInterestObj.Fulfillments.DeliveryPerson.ConfirmationCode);

        readytopick_tv.setText("YES");
        mindistance_tv.setText(AppUtil.getTwoDecimals(mInterest.Fulfillments.MinDistance) + " KM");
        maxdistance_tv.setText(AppUtil.getTwoDecimals(mInterest.Fulfillments.MaxDistance) + " KM");
        deliverydate_tv.setText(AppUtil.getLocalDateFormat(mInterest.Fulfillments.ExpirationDateTime));

        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        try {
            Phonenumber.PhoneNumber phoneNumber = phoneNumberUtil.parse(mInterest.Fulfillments.RetailerLocation.LocationContactPhone, "US");
            String usFormatNUmber = phoneNumberUtil.format(phoneNumber, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL);
            String finalNumber = usFormatNUmber.replace(" ", "-");
            Log.d(StartDelivery.class.getSimpleName(), "usFormatNUmber :: " + usFormatNUmber);
            Log.d(StartDelivery.class.getSimpleName(), "finalNumber :: " + finalNumber);
            phoneno_tv.setText(finalNumber);

        } catch (NumberParseException e) {
            e.printStackTrace();
            phoneno_tv.setText(mInterest.Fulfillments.RetailerLocation.LocationContactPhone);
        }

        name_tv.setText(mInterest.Fulfillments.RetailerLocation.LocationContactPerson);
        address_tv.setText(mInterest.Fulfillments.RetailerLocation.RetailerLocationAddress.AddressLine1 + ", " +
                mInterest.Fulfillments.RetailerLocation.RetailerLocationAddress.City + ", " +
                mInterest.Fulfillments.RetailerLocation.RetailerLocationAddress.State + " " +
                mInterest.Fulfillments.RetailerLocation.RetailerLocationAddress.CountryName
        );

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Date myDate = simpleDateFormat.parse(responseInterestObj.Fulfillments.ExpirationDateTime);
                            Date date = new Date();
                            System.out.println("service Date  " + myDate + ",current date" + date);
                            printDifference(date, myDate);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }, 0, 1000);


        startDeliveryAdapter = new StartDeliveryAdapter(this, mInterest.Fulfillments.Orders);
        orderlist_LI.setAdapter(startDeliveryAdapter);
        //Common.setListViewHeightBasedOnItems(orderlist_LI);
    }

    public void printDifference(Date startDate, Date endDate) {
        //milliseconds
        long different = endDate.getTime() - startDate.getTime();
        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        day_tv.setText("" + elapsedDays + " Days");
        time_tv.setText("" + elapsedHours + "H : " + elapsedMinutes + "M : " + elapsedSeconds + "S");

    }

    @Override
    public void onRefresh() {
        callGetMessagesAPI(false);
    }

    public void finishActivity() {
        Intent intent = new Intent(StartDelivery.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

}
