package com.biglynx.fulfiller.models;


public class AccountConfigModel {
    public String DirectDepositId;
    public String Fulfillerid;
    public String AccountType;
    public String AccountName;
    public String AccountNumber;
    public String RoutingNumber;
    public String Status;
    public String DateCreated;
    public String DateUpdated;
    public String BankName;
}
