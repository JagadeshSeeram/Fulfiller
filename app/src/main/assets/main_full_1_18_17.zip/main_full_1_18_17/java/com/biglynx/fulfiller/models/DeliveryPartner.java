package com.biglynx.fulfiller.models;

/**
 * Created by snehitha.chinnapally on 1/18/2017.
 */

public class DeliveryPartner {
    public String FulfillerId;
    public String PartnerStatus;
    public String Contactperson;
    public String JobTitle;
    public String Phone;
    public String ConfirmationCode;
}
