package com.biglynx.fulfiller.models;

/**
 * Created by Biglynx on 7/26/2016.
 */
public class DeliveryPerson {

    public String FulfillerFirstName;
    public String FulfillerMiddleName;
    public String FulfillerLastName;
    public String FulfillerEmailID;
}
