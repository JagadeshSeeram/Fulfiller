package com.biglynx.fulfiller.models;

/**
 * Created by snehitha.chinnapally on 1/10/2017.
 */

public class Fulfillerdefaults {
    public String FulfillerId;
    public String Proximity;
    public String PingInterval;
    public boolean ReadyFulfill;
}
