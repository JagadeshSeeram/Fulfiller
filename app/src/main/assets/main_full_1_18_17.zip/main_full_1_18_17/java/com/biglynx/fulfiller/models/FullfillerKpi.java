package com.biglynx.fulfiller.models;


public class FullfillerKpi {

    public String FulfilerId;
    public String Amount;
    public double NoOfMilesDriven;
    public String Count;

}
