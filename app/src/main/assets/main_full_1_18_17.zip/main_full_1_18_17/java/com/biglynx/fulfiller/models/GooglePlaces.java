package com.biglynx.fulfiller.models;

/**
 * Created by Biglynx on 8/4/2016.
 */

public class GooglePlaces {

    public String description;
    public String id;
}
