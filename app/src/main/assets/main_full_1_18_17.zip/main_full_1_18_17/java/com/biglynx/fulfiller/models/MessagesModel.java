package com.biglynx.fulfiller.models;

/**
 * Created by snehitha.chinnapally on 1/4/2017.
 */

public class MessagesModel {

    public String MessageId;
    public String FulfillmentId;
    public String FulfillerId;
    public String FlulfillerName;
    public String RetailerId;
    public String RetailerName;
    public String MessageFrom;
    public String Message;
    public String DateCreated;
}
