package com.biglynx.fulfiller.models;

/**
 * Created by snehitha.chinnapally on 12/22/2016.
 */
public class PaymentDetailsModel {

    public String Comments;
    public String DateCreated ;
    public String DateUpdated ;
    public String FulfillerId ;
    public String InterestId ;
    public double PayoutAmount ;
    public String PayoutDate ;
    public String PayoutId ;
    public String PayoutStatus ;
    public String PayoutreferenceId ;
    public String RetailerName ;

}
