package com.biglynx.fulfiller.models;

import java.io.Serializable;

/**
 * Created by Biglynx on 7/26/2016.
 */
public class Retailer implements Serializable{

    public String BusinessLegalName;
    public String CompanyEmail;
    public String Phone;
    public String CompanyLogo;

}
