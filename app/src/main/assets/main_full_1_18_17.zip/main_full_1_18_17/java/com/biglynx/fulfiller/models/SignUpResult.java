package com.biglynx.fulfiller.models;


public class SignUpResult {
}
