package com.biglynx.fulfiller.models;

/**
 * Copyright (c) 2016 BigLynx
 * <p>
 * All Rights reserved.
 */

/*
* @author Ramakrishna on 8/23/2016
* @version 1.0
*
*/

public class SpinnerOrders {
    public String name;
    public int id;

    public SpinnerOrders(String names, int ids) {
        this.name=names;
        this.id=ids;

    }
}
