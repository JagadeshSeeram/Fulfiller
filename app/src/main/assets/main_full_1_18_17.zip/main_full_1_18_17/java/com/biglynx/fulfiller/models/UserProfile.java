package com.biglynx.fulfiller.models;

public class UserProfile {
    public String BusinessLegalName;
    public String FirstName;
    public String Email;
    public String Phone;
    public String AddressLine1;
    public String City;
    public String State;
    public String Country;
    public String LoginProvider;
    public String ProviderKey;
    public String Password;
}
