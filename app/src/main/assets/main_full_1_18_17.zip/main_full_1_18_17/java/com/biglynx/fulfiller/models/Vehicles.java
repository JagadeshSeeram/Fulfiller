package com.biglynx.fulfiller.models;

import java.io.Serializable;

/**
 * Copyright (c) 206 BigLynx
 * <p>
 * All Rights reserved.
 */

/*
* @author Ramakrishna on 8/16/2016
* @version 1.0
*
*/

public class Vehicles implements Serializable{
    public String VehicleId;
    public String VehicleType;
    public String VehicleYear;
    public String LicencePlateNumber;
    public String VehicleInsurance;
    public String DateCreated;
    public String VehicleRegistration;

}
