package com.biglynx.fulfiller.network;

public interface NetworkOperationListener {
    void operationCompleted(NetworkResponse networkResponse);
}
