package com.biglynx.fulfiller.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.biglynx.fulfiller.models.SignInResult;

import org.json.JSONException;
import org.json.JSONObject;

public class AppPreferences {
    private static final String PREF_APP_RATE = "pref_app_rate";
    private static final String PREF_LAUNCH_COUNT = "pref_launch_count";
    private static final String SIGN_RESULT = "pref_app_rate";
    private static AppPreferences sInstance;
    private SharedPreferences mPrefs;

    private AppPreferences(Context paramContext) {
        this.mPrefs = paramContext.getSharedPreferences("app_prefs", 0);
    }

    public static AppPreferences getInstance(Context paramContext) {
        if (sInstance == null) {
            sInstance = new AppPreferences(paramContext);
        }
        return sInstance;
    }

    public boolean getAppRate() {
        return this.mPrefs.getBoolean(PREF_APP_RATE, true);
    }


    public void setSignInResult(SignInResult signInResult) {
        Editor localEditor = this.mPrefs.edit();
        if (signInResult == null) {
            localEditor.putString(SIGN_RESULT, "");
        }else {
            localEditor.putString(SIGN_RESULT, signInResult.toJSON().toString());
        }
        localEditor.commit();
    }

    public JSONObject getSignInResult() {
        Editor localEditor = this.mPrefs.edit();
        String string = mPrefs.getString(SIGN_RESULT, "");
        try {
            JSONObject jsonObject = new JSONObject(string);
            return jsonObject;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


    public void setAppRate(boolean paramBoolean) {
        Editor localEditor = this.mPrefs.edit();
        localEditor.putBoolean(PREF_APP_RATE, paramBoolean);
        localEditor.commit();
    }

    public int getLaunchCount() {
        return this.mPrefs.getInt(PREF_LAUNCH_COUNT, 0);
    }

    public void incrementLaunchCount() {
        int i = getLaunchCount();
        Editor localEditor = this.mPrefs.edit();
        localEditor.putInt(PREF_LAUNCH_COUNT, i + 1);
        localEditor.commit();
    }

    public void resetLaunchCount() {
        Editor localEditor = this.mPrefs.edit();
        localEditor.remove(PREF_LAUNCH_COUNT);
        localEditor.commit();
    }
}
