package com.biglynx.fulfiller.utils;


public class Constants {
    public static final String OOPS_SOMETHING_WENT_WRONG = "Oops something went wrong!!";

    public static final String FACEBOOK_LOGIN = "Facebook";
    public static final String GOOGLE_LOGIN = "Google";
}
